module.exports = {
  root: true,
  extends: '@react-native',
  rules: { 'react-native/no-inline-styles': 'off', semi: 'off', 'prettier/prettier': 'off' },
}
