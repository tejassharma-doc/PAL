"""
PAL MCP API - FastAPI Version
Webhook receiver for medical reports and external data
"""
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime
import asyncpg
import os
import json
import uuid
# Import SQLAlchemy dependencies for helper function
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from webhook_processor import process_webhook, WebhookProcessingError
from clinical_output_processor import process_clinical_output_webhook, ClinicalOutputProcessingError
from pal_auth import router as pal_auth_router, require_docehr_auth

# Configuration
PORT = int(os.getenv("PORT", "3001"))
API_KEY = os.getenv("PAL_API_KEY", "")
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")  # Optional signature verification

# Database configuration - construct URL from components
POSTGRES_USER = os.getenv("POSTGRES_USER", "pal")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "change_me_in_prod")
POSTGRES_HOST = os.getenv("POSTGRES_HOST", "db")
POSTGRES_PORT = os.getenv("POSTGRES_PORT", "5432")
POSTGRES_DB = os.getenv("POSTGRES_DB", "pal")

# Construct database URL
DATABASE_URL = f"postgresql://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"
ASYNC_DATABASE_URL = f"postgresql+asyncpg://{POSTGRES_USER}:{POSTGRES_PASSWORD}@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}"

print(f"🔧 Database URL: postgresql://{POSTGRES_USER}:***@{POSTGRES_HOST}:{POSTGRES_PORT}/{POSTGRES_DB}")

# Create FastAPI app
app = FastAPI(
    title="PAL MCP API",
    description="Webhook receiver for medical reports and external data",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Direction B: DocEHR -> PAL OAuth2 token endpoint (/api/v1/oauth/token)
app.include_router(pal_auth_router)

# Database connection pool (asyncpg for raw queries)
db_pool = None

# ── invoices table ───────────────────────────────────────────────────────────
# Structured store for payment/invoice webhooks (DocEHR → /api/v1/webhook/invoice).
# The raw event is still audited in webhook_events; this table is the queryable,
# de-duplicated projection. Id-like fields are TEXT (not UUID) so a malformed
# external value can never make the webhook fail and lose data — they remain
# castable to uuid for joins. Created idempotently on startup because this
# service has no migration framework of its own.
INVOICES_DDL = """
CREATE TABLE IF NOT EXISTS invoices (
    id                  UUID PRIMARY KEY,
    event               TEXT,
    reservation_id      TEXT,
    appointment_id      TEXT,
    invoice_id          TEXT,
    payment_id          TEXT,
    razorpay_payment_id TEXT,
    source              TEXT,
    raw_payload         JSONB       NOT NULL,
    received_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Idempotency: a retried webhook for the same payment updates in place rather
-- than inserting a duplicate. Partial so multiple rows without a payment_id
-- (e.g. non-payment invoice events) are still allowed.
CREATE UNIQUE INDEX IF NOT EXISTS invoices_payment_id_key
    ON invoices (payment_id) WHERE payment_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS invoices_invoice_id_idx     ON invoices (invoice_id);
CREATE INDEX IF NOT EXISTS invoices_appointment_id_idx ON invoices (appointment_id);
"""

# SQLAlchemy engine and session maker (for ORM helper functions)
engine = None
SessionLocal = None


@app.on_event("startup")
async def startup():
    """Initialize database connection pool and SQLAlchemy engine"""
    global db_pool, engine, SessionLocal

    try:
        # asyncpg pool for raw queries
        print(f"🔄 Creating database pool...")
        db_pool = await asyncpg.create_pool(
            DATABASE_URL,
            min_size=2,
            max_size=10,
            command_timeout=60,
            timeout=10  # 10 second connection timeout
        )
        print(f"✅ Database pool created successfully")

        # Ensure the invoices table exists (idempotent).
        try:
            async with db_pool.acquire() as conn:
                await conn.execute(INVOICES_DDL)
            print("✅ invoices table ready")
        except Exception as ddl_error:
            print(f"⚠️  Could not ensure invoices table: {ddl_error}")

        # SQLAlchemy async engine for ORM
        print(f"🔄 Creating SQLAlchemy engine...")
        engine = create_async_engine(
            ASYNC_DATABASE_URL,
            echo=False,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10
        )
        SessionLocal = async_sessionmaker(
            engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        print(f"✅ SQLAlchemy engine created successfully")

    except Exception as e:
        print(f"❌ Failed to initialize database: {e}")
        import traceback
        traceback.print_exc()
        # Don't raise - let the app start anyway so healthcheck can report the issue
        print("⚠️  Application starting without database connection")


@app.on_event("shutdown")
async def shutdown():
    """Close database connection pool and engine"""
    if db_pool:
        await db_pool.close()
        print("✅ Database pool closed")
    if engine:
        await engine.dispose()
        print("✅ SQLAlchemy engine disposed")


# Dependency for asyncpg connection (raw queries)
async def get_db():
    async with db_pool.acquire() as connection:
        yield connection


# Dependency for SQLAlchemy session (ORM operations)
async def get_db_session():
    async with SessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# Models
class WebhookPayload(BaseModel):
    """Generic webhook payload - accepts any JSON structure"""
    class Config:
        extra = "allow"  # Allow any additional fields


class WebhookResponse(BaseModel):
    success: bool
    message: str
    webhook_id: Optional[str] = None
    timestamp: Optional[str] = None
    event_type: Optional[str] = None
    dataReceived: bool = False


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    status = {
        "status": "ok",
        "service": "pal-mcp-api",
        "version": "2.0.0",
        "database": {
            "connected": False,
            "pool_size": 0
        }
    }

    # Check database connection
    if db_pool:
        try:
            # Try a simple query
            async with db_pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            status["database"]["connected"] = True
            status["database"]["pool_size"] = db_pool.get_size()
        except Exception as e:
            status["status"] = "degraded"
            status["database"]["error"] = str(e)
    else:
        status["status"] = "degraded"
        status["database"]["error"] = "Pool not initialized"

    return status


# Webhook endpoint - NO AUTH REQUIRED
@app.post("/api/v1/webhook", response_model=WebhookResponse)
async def receive_webhook(
    request: Request,
    db: asyncpg.Connection = Depends(get_db),
    db_session: AsyncSession = Depends(get_db_session),
    _auth=Depends(require_docehr_auth),
):
    """
    Receive and store webhook data.
    Accepts any JSON structure and stores it in PostgreSQL JSONB.

    Flow:
    1. Store webhook in webhook_events table (raw storage)
    2. Call process_webhook helper to:
       - Verify signature (if configured)
       - Validate payload
       - Find/create phone user
       - Find/create patient
       - Upsert appointments
       - Mark webhook as processed
    """
    # Get request body as JSON
    try:
        payload = await request.json()
    except Exception as e:
        payload = {}

    # Get headers
    headers = dict(request.headers)

    # Current timestamp
    timestamp = datetime.utcnow()

    # Log to console
    print("========== WEBHOOK RECEIVED ==========")
    print(f"Timestamp: {timestamp.isoformat()}")
    print(f"Headers: {json.dumps(headers, indent=2)}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print("======================================")

    webhook_id = None

    try:
        # Determine event type from payload structure
        event_type = payload.get("event", "unknown")  # Use explicit event field first

        # Fall back to structure detection
        if event_type == "unknown":
            if payload.get("lab_reports") and isinstance(payload.get("lab_reports"), list):
                event_type = "medical_report"
            elif payload.get("test"):
                event_type = "test"
            elif payload.get("appointment_id") or payload.get("appointments"):
                event_type = "appointment"

        # Extract source from headers or payload
        source = headers.get("x-webhook-source") or payload.get("source", "unknown")

        # STEP 1: Store webhook in database (raw storage)
        query = """
            INSERT INTO webhook_events
            (event_type, source, timestamp, payload, headers, processed)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, timestamp, event_type
        """

        row = await db.fetchrow(
            query,
            event_type,
            source,
            timestamp,
            json.dumps(payload),
            json.dumps(headers),
            False  # Not processed yet
        )

        webhook_id = int(row["id"])
        print(f"✅ Webhook saved to database: {webhook_id}")

        # STEP 2: Process webhook based on event type
        try:
            # Route to appropriate processor
            if event_type == "clinical_output_created":
                # Clinical output webhook - comprehensive processing
                processing_result = await process_clinical_output_webhook(
                    webhook_id=webhook_id,
                    payload=payload,
                    db=db_session
                )
            else:
                # Simple appointment/medical report webhook
                processing_result = await process_webhook(
                    webhook_id=webhook_id,
                    payload=payload,
                    headers=headers,
                    db=db_session,
                    signature_secret=WEBHOOK_SECRET if WEBHOOK_SECRET else None
                )

            print(f"✅ Webhook processed successfully:")
            print(f"   - Phone User: {processing_result.get('phone_user_id')}")
            print(f"   - Patient: {processing_result.get('patient_id')}")
            if 'appointments_processed' in processing_result:
                print(f"   - Appointments: {processing_result['appointments_processed']}")
            if 'consultation_id' in processing_result:
                print(f"   - Consultation: {processing_result['consultation_id']}")
            if 'prescription_ids' in processing_result:
                print(f"   - Prescriptions: {len(processing_result['prescription_ids'])}")
            if 'lab_test_ids' in processing_result:
                print(f"   - Lab Tests: {len(processing_result['lab_test_ids'])}")

            return WebhookResponse(
                success=True,
                message=f"Webhook received and processed successfully",
                webhook_id=str(webhook_id),
                timestamp=str(row['timestamp']),
                event_type=row['event_type'],
                dataReceived=len(payload) > 0
            )

        except (WebhookProcessingError, ClinicalOutputProcessingError) as process_error:
            # Processing failed, but webhook is still stored
            print(f"⚠️  Webhook stored but processing failed: {process_error}")

            return WebhookResponse(
                success=True,
                message=f"Webhook received but processing failed: {str(process_error)}",
                webhook_id=str(webhook_id) if webhook_id is not None else None,
                timestamp=str(row['timestamp']),
                event_type=row['event_type'],
                dataReceived=len(payload) > 0
            )

    except Exception as error:
        print(f"❌ Error saving webhook: {error}")
        import traceback
        traceback.print_exc()

        # Still return success to sender to avoid retries
        return WebhookResponse(
            success=True,
            message="Webhook received (storage pending)",
            webhook_id=str(webhook_id) if webhook_id is not None else None,
            dataReceived=len(payload) > 0
        )


# Get webhooks (optional - for debugging)
@app.get("/api/v1/webhooks")
async def get_webhooks(
    event_type: Optional[str] = None,
    processed: Optional[bool] = None,
    limit: int = 50,
    offset: int = 0,
    db: asyncpg.Connection = Depends(get_db)
):
    """Get stored webhooks with optional filters"""

    conditions = []
    params = []
    param_count = 1

    if event_type:
        conditions.append(f"event_type = ${param_count}")
        params.append(event_type)
        param_count += 1

    if processed is not None:
        conditions.append(f"processed = ${param_count}")
        params.append(processed)
        param_count += 1

    where_clause = " AND ".join(conditions) if conditions else "1=1"

    query = f"""
        SELECT * FROM webhook_events
        WHERE {where_clause}
        ORDER BY timestamp DESC
        LIMIT ${param_count}
        OFFSET ${param_count + 1}
    """
    params.extend([limit, offset])

    rows = await db.fetch(query, *params)

    webhooks = []
    for row in rows:
        webhooks.append({
            "id": str(row['id']),
            "event_type": row['event_type'],
            "source": row['source'],
            "timestamp": str(row['timestamp']),
            "payload": json.loads(row['payload']) if row['payload'] else {},
            "processed": row['processed'],
            "created_at": str(row['created_at'])
        })

    return {
        "total": len(webhooks),
        "webhooks": webhooks
    }


# Get specific webhook by ID
@app.get("/api/v1/webhooks/{webhook_id}")
async def get_webhook_by_id(
    webhook_id: str,
    db: asyncpg.Connection = Depends(get_db)
):
    """Get a specific webhook by ID"""

    query = "SELECT * FROM webhook_events WHERE id = $1"
    row = await db.fetchrow(query, webhook_id)

    if not row:
        raise HTTPException(status_code=404, detail="Webhook not found")

    return {
        "id": str(row['id']),
        "event_type": row['event_type'],
        "source": row['source'],
        "timestamp": str(row['timestamp']),
        "payload": json.loads(row['payload']) if row['payload'] else {},
        "headers": json.loads(row['headers']) if row['headers'] else {},
        "processed": row['processed'],
        "processed_at": str(row['processed_at']) if row['processed_at'] else None,
        "patient_id": str(row['patient_id']) if row['patient_id'] else None,
        "created_at": str(row['created_at'])
    }


# iNutriMon Webhook endpoint - NO AUTH REQUIRED
@app.post("/api/v1/webhook-inutrimon", response_model=WebhookResponse)
async def receive_inutrimon_webhook(
    request: Request,
    db: asyncpg.Connection = Depends(get_db)
):
    """
    Receive webhook data from iNutriMon system.
    Accepts any JSON structure for diet plans, nutrition data, recipes, etc.
    """
    # Get request body as JSON
    try:
        payload = await request.json()
    except Exception as e:
        payload = {}

    # Get headers
    headers = dict(request.headers)

    # Current timestamp
    timestamp = datetime.utcnow()

    # Log to console
    print("========== iNUTRIMON WEBHOOK RECEIVED ==========")
    print(f"Timestamp: {timestamp.isoformat()}")
    print(f"Headers: {json.dumps(headers, indent=2)}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print("================================================")

    webhook_id = None

    try:
        # Event type from payload or default to 'nutrition_data'
        event_type = payload.get("event", "nutrition_data")

        # Source is always iNutriMon
        source = "inutrimon"

        # STEP 1: Store webhook in database (raw storage)
        query = """
            INSERT INTO webhook_events
            (event_type, source, timestamp, payload, headers, processed)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, timestamp, event_type
        """

        row = await db.fetchrow(
            query,
            event_type,
            source,
            timestamp,
            json.dumps(payload),
            json.dumps(headers),
            False  # Not processed yet
        )

        webhook_id = str(row['id'])
        print(f"✅ iNutriMon webhook saved to database: {webhook_id}")

        # TODO: Add iNutriMon-specific processing here if needed
        # For now, just store the raw data

        return WebhookResponse(
            success=True,
            message=f"iNutriMon webhook received and stored successfully",
            webhook_id=webhook_id,
            timestamp=str(row['timestamp']),
            event_type=row['event_type'],
            dataReceived=len(payload) > 0
        )

    except Exception as error:
        print(f"❌ Error saving iNutriMon webhook: {error}")
        import traceback
        traceback.print_exc()

        # Still return success to sender to avoid retries
        return WebhookResponse(
            success=True,
            message="iNutriMon webhook received (storage pending)",
            webhook_id=webhook_id if webhook_id else None,
            dataReceived=len(payload) > 0
        )


# Invoice / Payment Confirmation Webhook - NO AUTH REQUIRED
async def _project_appointment_from_invoice(payload: dict, db: asyncpg.Connection) -> None:
    """
    Additive projection of a DocEHR `appointment_payment_completed` payload into
    the shared `appointments` table so the booked visit shows up in the Visits
    section (GET /visits/patient/{id}, which reads `appointments` by patient_id).

    Identity: PHONE ONLY. The patient is matched against `patients.phone`
    (comparing the last 10 digits, so stored country codes / formatting don't
    matter). If no PAL patient has that phone yet, the appointment is skipped —
    we never create a patient here. Doctor/clinic are resolved by external_id and
    left NULL if unknown (doctor_name/clinic_name are stored as text regardless).

    Idempotent on `external_appointment_id`. This never raises to the caller's
    happy path: failures are logged and swallowed so the invoice/audit writes and
    the webhook ack are unaffected.
    """
    import re

    appt = payload.get("appointment") or {}
    patient = payload.get("patient") or {}
    doctor = payload.get("doctor") or {}
    clinic = payload.get("clinic") or {}

    ext_appt_id = appt.get("id")
    if not ext_appt_id:
        print("ℹ️  Appointment projection skipped: no appointment.id in payload")
        return

    # slot_time is required — a NULL would make the Visits endpoint fail for this
    # patient, so skip rather than write a half-row.
    slot_raw = appt.get("date_time")
    if not slot_raw:
        d, t = appt.get("date"), appt.get("time")
        slot_raw = f"{d}T{t}" if d and t else d
    if not slot_raw:
        print("ℹ️  Appointment projection skipped: no appointment date/time in payload")
        return
    # asyncpg requires a real datetime for a timestamptz param (not a string).
    try:
        slot_dt = datetime.fromisoformat(str(slot_raw).replace("Z", "+00:00"))
    except ValueError:
        print(f"ℹ️  Appointment projection skipped: unparseable date/time {slot_raw!r}")
        return

    # Patient: match by phone only (last 10 digits), never create.
    phone_digits = re.sub(r"\D", "", patient.get("phone") or "")
    if len(phone_digits) < 10:
        print("ℹ️  Appointment projection skipped: no usable patient.phone")
        return
    phone_last10 = phone_digits[-10:]
    prow = await db.fetchrow(
        "SELECT id FROM patients "
        "WHERE right(regexp_replace(coalesce(phone, ''), '\\D', '', 'g'), 10) = $1 "
        "LIMIT 1",
        phone_last10,
    )
    if not prow:
        print(f"ℹ️  Appointment projection skipped: no PAL patient with phone …{phone_last10} "
              f"(will show in Visits once that patient exists)")
        return
    patient_id = prow["id"]

    # Doctor / clinic: resolve by external_id; leave NULL if unknown.
    doctor_id = None
    if doctor.get("id"):
        drow = await db.fetchrow(
            "SELECT id FROM doctors WHERE external_id = $1 LIMIT 1", str(doctor["id"])
        )
        doctor_id = drow["id"] if drow else None
    clinic_id = None
    if clinic.get("id"):
        crow = await db.fetchrow(
            "SELECT id FROM clinics WHERE external_id = $1 LIMIT 1", str(clinic["id"])
        )
        clinic_id = crow["id"] if crow else None

    duration = appt.get("duration_minutes") or 30
    appt_type = appt.get("type")
    status = appt.get("status") or "scheduled"
    reason = appt.get("reason_for_visit")
    notes = appt.get("notes")
    doctor_name = doctor.get("name")
    clinic_name = clinic.get("name")

    # Pre-visit interview link (public URL the patient can open to fill it in).
    previsit = payload.get("previsit") or {}
    previsit_url = previsit.get("public_url")
    previsit_status = previsit.get("status")

    existing = await db.fetchrow(
        "SELECT id FROM appointments WHERE external_appointment_id = $1 LIMIT 1",
        str(ext_appt_id),
    )
    if existing:
        await db.execute(
            """
            UPDATE appointments SET
                patient_id = $2, doctor_id = $3, clinic_id = $4,
                appointment_date = $5::timestamptz, slot_time = $5::timestamptz,
                duration_minutes = $6, type = $7, status = $8,
                reason_for_visit = $9, notes = $10,
                doctor_name = $11, clinic_name = $12,
                previsit_url = $13, previsit_status = $14, updated_at = NOW()
            WHERE id = $1
            """,
            existing["id"], patient_id, doctor_id, clinic_id,
            slot_dt, duration, appt_type, status, reason, notes, doctor_name, clinic_name,
            previsit_url, previsit_status,
        )
        print(f"✅ Appointment updated in appointments — id: {existing['id']}")
    else:
        await db.execute(
            """
            INSERT INTO appointments
                (id, external_appointment_id, patient_id, doctor_id, clinic_id,
                 appointment_date, slot_time, duration_minutes, type, status,
                 reason_for_visit, notes, doctor_name, clinic_name,
                 previsit_url, previsit_status,
                 created_at, updated_at)
            VALUES
                (gen_random_uuid(), $1, $2, $3, $4,
                 $5::timestamptz, $5::timestamptz, $6, $7, $8,
                 $9, $10, $11, $12,
                 $13, $14,
                 NOW(), NOW())
            """,
            str(ext_appt_id), patient_id, doctor_id, clinic_id,
            slot_dt, duration, appt_type, status, reason, notes, doctor_name, clinic_name,
            previsit_url, previsit_status,
        )
        print(f"✅ Appointment inserted into appointments for patient {patient_id} "
              f"(external_appointment_id: {ext_appt_id})")


@app.post("/api/v1/webhook/invoice", response_model=WebhookResponse)
async def receive_invoice_webhook(
    request: Request,
    db: asyncpg.Connection = Depends(get_db),
    _auth=Depends(require_docehr_auth),
):
    """
    Receive payment/invoice confirmation from DocEHR (or any source).
    Accepts any JSON — no schema enforced. Raw data is stored and logged.
    Distribution into specific tables comes later once the shape is confirmed.
    """
    try:
        payload = await request.json()
    except Exception:
        payload = {}

    headers = dict(request.headers)
    timestamp = datetime.utcnow()

    print("========== INVOICE WEBHOOK RECEIVED ==========")
    print(f"Timestamp : {timestamp.isoformat()}")
    print(f"Source    : {headers.get('x-webhook-source', 'unknown')}")
    print(f"Payload   : {json.dumps(payload, indent=2)}")
    print("==============================================")

    webhook_id = None

    event_type = payload.get("event", "invoice")
    source = headers.get("x-webhook-source") or payload.get("source", "docehr")

    # STEP 1: raw audit trail — keep the untouched event in webhook_events.
    try:
        row = await db.fetchrow(
            """
            INSERT INTO webhook_events
                (event_type, source, timestamp, payload, headers, processed)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, timestamp, event_type
            """,
            event_type,
            source,
            timestamp,
            json.dumps(payload),
            json.dumps(headers),
            True,  # projected into invoices below, so mark processed
        )
        webhook_id = str(row["id"])
        print(f"✅ Invoice webhook audited in webhook_events — id: {webhook_id}")
    except Exception as error:
        print(f"⚠️  Could not audit invoice webhook: {error}")

    # STEP 2: structured projection — upsert the parsed fields into invoices.
    invoice_row_id = None
    invoice_saved = False
    try:
        invoice_row_id = str(uuid.uuid4())
        result = await db.fetchrow(
            """
            INSERT INTO invoices
                (id, event, reservation_id, appointment_id, invoice_id,
                 payment_id, razorpay_payment_id, source, raw_payload, received_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            ON CONFLICT (payment_id) WHERE payment_id IS NOT NULL
            DO UPDATE SET
                event               = EXCLUDED.event,
                reservation_id      = EXCLUDED.reservation_id,
                appointment_id      = EXCLUDED.appointment_id,
                invoice_id          = EXCLUDED.invoice_id,
                razorpay_payment_id = EXCLUDED.razorpay_payment_id,
                source              = EXCLUDED.source,
                raw_payload         = EXCLUDED.raw_payload,
                received_at         = EXCLUDED.received_at
            RETURNING id
            """,
            invoice_row_id,
            event_type,
            payload.get("reservation_id"),
            payload.get("appointment_id"),
            payload.get("invoice_id"),
            payload.get("payment_id"),
            payload.get("razorpay_payment_id"),
            payload.get("source") or source,
            json.dumps(payload),
            timestamp,
        )
        invoice_row_id = str(result["id"])
        invoice_saved = True
        print(f"✅ Invoice saved to invoices table — id: {invoice_row_id}")

    except Exception as error:
        print(f"❌ Error saving invoice to invoices table: {error}")
        import traceback
        traceback.print_exc()

    # STEP 3: project the booked appointment into `appointments` so it appears in
    # the Visits section. Fully additive — guarded so it can never fail the
    # webhook ack or the invoice/audit writes above.
    try:
        await _project_appointment_from_invoice(payload, db)
    except Exception as error:
        print(f"⚠️  Could not project appointment into appointments table: {error}")
        import traceback
        traceback.print_exc()

    return WebhookResponse(
        success=True,
        message="Invoice webhook received and saved" if invoice_saved
                else "Invoice webhook received (invoices save pending)",
        webhook_id=invoice_row_id or webhook_id,
        timestamp=str(timestamp),
        event_type=event_type,
        dataReceived=len(payload) > 0,
    )


if __name__ == "__main__":
    import uvicorn
    print(f"🚀 Starting PAL MCP API on port {PORT}")
    print(f"📍 Webhook endpoint:         http://localhost:{PORT}/api/v1/webhook")
    print(f"📍 iNutriMon webhook:        http://localhost:{PORT}/api/v1/webhook-inutrimon")
    print(f"📍 Invoice/payment webhook:  http://localhost:{PORT}/api/v1/webhook/invoice")
    uvicorn.run(app, host="0.0.0.0", port=PORT)
