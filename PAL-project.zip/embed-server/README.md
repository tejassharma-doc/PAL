# PAL EmbeddingGemma service (CPU, always-on)

Keep-warm embedding microservice for the PubMed RAG pipeline. Loads EmbeddingGemma
once on CPU and serves normalized query/document embeddings over HTTP. Docker keeps
it running across crashes and reboots.

## Prerequisites (on APP05)
1. Docker + docker compose installed.
2. Accept the model's license on huggingface.co and create a read token.
3. Confirm the model id matches what embedded the corpus (`embed_log.txt`) and that
   its output dim is 768.

## Setup
```bash
# 1. Copy this folder to the server
scp -r embed-server tejash@BANLOCPAPP05:/data/apps/docmode/

# 2. On the server
cd /data/apps/docmode/embed-server
mkdir -p /data/apps/docmode/hf-cache
export HF_TOKEN=hf_xxxxxxxxxxxxxxxxx          # token with accepted license

# 3. (optional) set the confirmed model id
#    edit docker-compose.yml -> EMBED_MODEL_ID

# 4. Build + start (first run downloads the model, ~1.5-3 GB)
docker compose up -d --build

# 5. Watch it come up (model load takes ~1-2 min on CPU)
docker compose logs -f embed
```

## Test
```bash
curl -s http://127.0.0.1:8080/health
# {"ready": true, "model": "google/embeddinggemma-2", "dim": 768}

curl -s -X POST http://127.0.0.1:8080/embed/query \
  -H 'Content-Type: application/json' \
  -d '{"text":"What lowers LDL cholesterol?"}' | head -c 200
```

## Use in the RAG search
Replace the in-process `embed_model.encode(...)` with a call to this service:
```python
import requests
q = requests.post("http://127.0.0.1:8080/embed/query",
                  json={"text": query}, timeout=30).json()["embedding"]
# then: SELECT ... ORDER BY embedding <=> %s::vector LIMIT k;  (pass q)
```

## Operate
- Status:   `docker compose ps`
- Restart:  `docker compose restart embed`
- Stop:     `docker compose down`
- Logs:     `docker compose logs -f embed`

## Notes for an 8 GB box
- One worker only (set in the Dockerfile) — more workers = more model copies = OOM.
- `mem_limit: 5g` leaves room for Postgres/pgvector. If the container gets OOM-killed,
  check `docker stats` and raise/lower to balance against Postgres.
- CPU/fp32 is correct here; fp16/bf16 are slower on CPU.
- This is for QUERY embedding at runtime (low volume). Do not re-embed the whole
  corpus on CPU — reuse the existing vectors.
