Local REPO snapshot of the PubMed/bioRxiv -> Gemma flow, 20261028-140729.
NOTE: this is the REPO version, which may differ from what runs on APP07.
The authoritative backup must be taken on APP07 with scripts/backup-mcp-flow.sh
